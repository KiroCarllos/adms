function redirectToPage() {
    var selectElement = document.getElementById("name");
    var selectedValue = selectElement.value;
    switch (selectedValue) {
      case "first":
        window.location.href = "student1.html"; // Redirect to page1.html for Student 1
        break;
      case "second":
        window.location.href = "student2.html"; // Redirect to page2.html for Student 2
        break;
      
      default:
        break;
    }
  }