function redirectToPage() {
    var selectedValue = document.getElementById("Semester").value;
    if (selectedValue === "first") {
        // Redirect to the first semester page
        window.location.href = "firstsemester.html";
    } else if (selectedValue === "second") {
        // Redirect to the second semester page
        window.location.href = "secondsemester.html";
    }
}
