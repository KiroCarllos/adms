function redirectToPage() {
    var selectedValue = document.getElementById("Semester").value;
    if (selectedValue === "second") {
        // Redirect to the first semester page
        window.location.href = "secondsemester.html";
    
    }
}
