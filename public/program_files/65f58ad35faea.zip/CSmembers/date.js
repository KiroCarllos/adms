
  function validateDate(textarea) {
    var input = textarea.value.trim();
    var regex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
    var valid = regex.test(input);

    if (!valid) {
      textarea.classList.add("invalid");
      document.getElementById("date-error").style.display = "inline";
    } else {
      textarea.classList.remove("invalid");
      document.getElementById("date-error").style.display = "none";
    }
  }